#!/bin/bash
PRG="$0"
P=`dirname $PRG`
cd $P
python proximity.py
